Run Part2 code through Jupyter notebook
Attached part1
part2 was removed

Images for html are in html/images/